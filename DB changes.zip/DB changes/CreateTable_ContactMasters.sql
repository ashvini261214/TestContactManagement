USE [ContactManagement]
GO

/****** Object:  Table [dbo].[ContactMasters]    Script Date: 04-01-2020 10:37:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ContactMasters](
	[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_ContactMasters_ID]  DEFAULT (newid()),
	[MobileNumber] [varchar](50) NOT NULL,
	[FirstName] [varchar](50) NOT NULL,
	[LastName] [varchar](50) NOT NULL,
	[EmailAddress] [varchar](200) NULL,
	[Address] [varchar](500) NULL,
	[IsActive] [bit] NOT NULL CONSTRAINT [DF_ContactMasters_IsDeleted]  DEFAULT ((1)),
	[IsDeleted] [bit] NOT NULL CONSTRAINT [DF_ContactMasters_IsDeleted_1]  DEFAULT ((0)),
	[CreatedDate] [datetime] NOT NULL CONSTRAINT [DF_ContactMasters_CreatedDate]  DEFAULT (getdate()),
	[ModifiedDate] [datetime] NOT NULL CONSTRAINT [DF_ContactMasters_ModifiedDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_dbo.ContactMasters] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


