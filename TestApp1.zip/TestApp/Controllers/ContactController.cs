﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestApp.Models;

namespace TestApp.Controllers
{
    public class ContactController : Controller
    {
        private ContactDBContext db = new ContactDBContext();

        // GET: Contact
        public async Task<ActionResult> Index()
        {
            return View(await db.ContactMasters.Where(c=>c.IsDeleted==false).OrderBy(c=>c.CreatedDate).ToListAsync());
        }

        // GET: Contact/Details/5
        public async Task<ActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ContactMaster contactMaster = await db.ContactMasters.FindAsync(id);
            if (contactMaster == null)
            {
                return HttpNotFound();
            }
            return View(contactMaster);
        }

        // GET: Contact/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Contact/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "ID,MobileNumber,FirstName,LastName,EmailAddress,Address,IsActive,CreatedDate,ModifiedDate")] ContactMaster contactMaster)
        {
            if (ModelState.IsValid)
            {
                contactMaster.ID = Guid.NewGuid();
                contactMaster.CreatedDate = DateTime.Now;
                contactMaster.ModifiedDate = DateTime.Now;
                db.ContactMasters.Add(contactMaster);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(contactMaster);
        }

        // GET: Contact/Edit/5
        public async Task<ActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ContactMaster contactMaster = await db.ContactMasters.FindAsync(id);
            if (contactMaster == null)
            {
                return HttpNotFound();
            }
            return View(contactMaster);
        }

        // POST: Contact/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "ID,MobileNumber,FirstName,LastName,EmailAddress,Address,IsActive,CreatedDate,ModifiedDate")] ContactMaster contactMaster)
        {
            if (ModelState.IsValid)
            {
                contactMaster.ModifiedDate = DateTime.Now;
                db.Entry(contactMaster).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(contactMaster);
        }

        // GET: Contact/Delete/5
        public async Task<ActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ContactMaster contactMaster = await db.ContactMasters.FindAsync(id);
            if (contactMaster == null)
            {
                return HttpNotFound();
            }
            return View(contactMaster);
        }

        // POST: Contact/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(Guid id)
        {
            ContactMaster contactMaster = await db.ContactMasters.FindAsync(id);
            contactMaster.IsActive = false;
            contactMaster.IsDeleted = true;
            db.Entry(contactMaster).State = EntityState.Modified;
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
