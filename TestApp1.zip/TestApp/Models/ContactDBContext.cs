﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace TestApp.Models
{
    public class ContactDBContext : DbContext
    {
        public ContactDBContext() : base("mydbconnection")
        {
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer<ContactDBContext>(null);
            base.OnModelCreating(modelBuilder);
        }
        public  DbSet<ContactMaster> ContactMasters { get; set; }
    }
}