using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TestApp.Models
{
    public class ContactMaster
    {
        [Key]
        public Guid ID { get; set; }
        [Required]
        [StringLength(50)]
        [RegularExpression(@"^([\+][0-9]{1,3}([ \.\-])?)?([\(]{1}[0-9]{3}[\)])?([0-9A-Z \.\-]{1,32})((x|ext|extension)?[0-9]{1,4}?)$", ErrorMessage = "Mobile Number is not valid")]
        public string MobileNumber { get; set; }
        [Required]
        [StringLength(50)]
        [RegularExpression(@"^([a-zA-z\s]{2,})$",ErrorMessage ="First Name is not valid")]
        public string FirstName { get; set; }
        [Required]
        [StringLength(50)]
        [RegularExpression(@"^([a-zA-z\s]{2,})$", ErrorMessage = "Last Name is not valid")]
        public string LastName { get; set; }
        [StringLength(200)]
        [RegularExpression(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$",ErrorMessage ="Email address is not valid.")]
        public string EmailAddress { get; set; }
        [StringLength(500)]
        public string Address { get; set; }
        [Display(Name = "Active")]
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}